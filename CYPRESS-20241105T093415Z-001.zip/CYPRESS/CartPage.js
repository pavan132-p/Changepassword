class CartPage {
    proceedToCheckout() {
      cy.get('.alert-success').contains('Shopping Cart').click();
      cy.get('a[href$="checkout"]').click();
      cy.get('input[value="Continue"]').click({ multiple: true });
    }
  }
  export default CartPage;