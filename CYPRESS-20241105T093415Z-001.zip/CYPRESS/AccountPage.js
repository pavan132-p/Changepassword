class AccountPage {
    navigateToMyAccount() {
      cy.get('a[href$="account/account"]').click();
    }
  
    changePassword(newPassword) {
      cy.get('a[href$="password"]').click();
      cy.get('#input-password').type(newPassword);
      cy.get('#input-confirm').type(newPassword);
      cy.get('input[type="submit"]').click();
    }
  }
  export default AccountPage;